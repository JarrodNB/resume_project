import os
import time
import urllib.request

def check(url):
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            return None if response.status == 200 else f"{url} returned {response.status}"
    except Exception as error:
        return f"{url} failed: {error}"

def handler(event, context):
    failed = []
    for url in os.environ["URLS"].split(","):
        problem = check(url)
        if problem:
            time.sleep(5)  # one retry, so a single dropped request does not send an alert
            problem = check(url)
        if problem:
            failed.append(problem)
    if failed:
        raise RuntimeError("; ".join(failed))
